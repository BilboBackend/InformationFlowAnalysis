module LatticeTest where
-- class MyersLiskov a where 
import Data.Lattice as LA 

data Sec = Low | High 

-- instance Lattice Sec  where 
--   (\/) Low High = High
--   (\/) High Low = High
--   (/\) Low High = Low 
--   (/\) High Low = Low   
--



readers :: Label -> Owner -> Readers 
readers l o = case HM.lookup o l of 
                Just s -> s 
                Nothing -> Set.empty

allReaders :: Label -> Readers 
allReaders l = HM.foldl Set.union Set.empty l 

effectiveReaders :: Label -> Readers 
effectiveReaders l = HM.foldl Set.intersection (allReaders l) l

sup :: (Lattice a) => a -> a -> a 
sup l1 l2 = Set.isSubsetOf l1owners l2owners where
                     l1owners = Set.fromList (HM.keys l1) 
                     l2owners = Set.fromList (HM.keys l2) 


-- ownerSubset :: Label -> Label -> Bool
-- ownerSubset l1 l2 = Set.isSubsetOf l1owners l2owners where
--                     l1owners = Set.fromList (HM.keys l1) 
--                     l2owners = Set.fromList (HM.keys l2) 
--
-- readersSupset :: Label -> Label -> Bool
-- readersSupset l1 l2 = all (\owner -> Set.isSubsetOf (readers l2 owner) (readers l1 owner)) l1owners 
--   where l1owners = Set.fromList (HM.keys l1) 
--
-- l1_lt_l2 :: Label -> Label -> Bool
-- l1_lt_l2 l1 l2 = (ownerSubset l1 l2) && (readersSupset l1 l2) 
--
-- join :: Label -> Label -> Label 
-- join l1 l2 = HM.unionWith Set.intersection l1 l2 
--
--
